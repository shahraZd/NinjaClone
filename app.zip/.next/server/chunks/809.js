"use strict";
exports.id = 809;
exports.ids = [809];
exports.modules = {

/***/ 40809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_FAQ)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@material-tailwind/react"
var react_ = __webpack_require__(84715);
;// CONCATENATED MODULE: ./src/components/Accordion.jsx



function Icon({ id , open  }) {
    return /*#__PURE__*/ jsx_runtime.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: `${id === open ? "rotate-180" : ""} h-5 w-5 transition-transform`,
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        strokeWidth: 2,
        children: /*#__PURE__*/ jsx_runtime.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M19 9l-7 7-7-7"
        })
    });
}
const MyAccordion = ({ item  })=>{
    const [open, setOpen] = (0,external_react_.useState)(0);
    const handleOpen = (value)=>{
        setOpen(open === value ? 0 : value);
    };
    //   useEffect(() => {
    //     setOpen(0);
    //   }, [open]);
    const customAnimation = {
        mount: {
            scale: 1
        },
        unmount: {
            scale: 0.9
        }
    };
    return /*#__PURE__*/ jsx_runtime.jsx(external_react_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(react_.Accordion, {
            open: open === item.order,
            icon: /*#__PURE__*/ jsx_runtime.jsx(Icon, {
                id: item.order,
                open: open
            }),
            animate: customAnimation,
            children: [
                /*#__PURE__*/ jsx_runtime.jsx(react_.AccordionHeader, {
                    onClick: ()=>handleOpen(item.order),
                    className: ` hover:text-primary-200 ${open === item.order ? "text-primary-500" : "text-white"}`,
                    children: item.question
                }),
                /*#__PURE__*/ jsx_runtime.jsx(react_.AccordionBody, {
                    className: "text-white text-base sm:text-sm",
                    children: item.answer
                })
            ]
        })
    });
};
/* harmony default export */ const Accordion = (MyAccordion);

;// CONCATENATED MODULE: ./public/faq.json
const faq_namespaceObject = JSON.parse('[{"order":1,"question":"How does your agency excel in community management?","answer":"Our expert community managers foster vibrant and engaged online communities within the Web3 ecosystem. They drive participation, cultivate brand advocates, and ensure a sense of belonging."},{"order":2,"question":"what is the client onboarding process like?","answer":"Our client onboarding process is streamlined and straightforward. We begin with an initial consultation, develop a tailored marketing strategy, provide a proposal, kick off the campaign, provide regular updates and reports, and maintain open communication throughout the engagement."},{"order":3,"question":"How can I get started with your agency?","answer":"Getting started is easy! Simply Book a call and meet with one of our experts to discuss your specific marketing needs and how we can help you achieve your goals in the Web3 ecosystem."}]');
;// CONCATENATED MODULE: ./src/pages/home/FAQ.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const FAQ = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
        className: "bg-primary-1000 text-white py-12 text-center flex flex-col justify-center align-center px-7",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("h1", {
                className: "text-2xl my-10 ",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                        className: "text-5xl",
                        children: "FAQ. "
                    }),
                    "Popular Question From Our Clients"
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "mx-auto w-1/2 sm:w-full",
                children: faq_namespaceObject.map((e)=>/*#__PURE__*/ jsx_runtime.jsx(Accordion, {
                        item: e
                    }, e.order))
            })
        ]
    });
};
/* harmony default export */ const home_FAQ = (FAQ);


/***/ })

};
;