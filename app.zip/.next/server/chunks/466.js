"use strict";
exports.id = 466;
exports.ids = [466];
exports.modules = {

/***/ 20466:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_Testimonials)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
;// CONCATENATED MODULE: ./public/testimonials.json
const testimonials_namespaceObject = JSON.parse('[{"name":"Marc Dane","position":"CEO of CryptoTech Inc.","content":"HypeFarm\'s exceptional community management expertise exceeded our expectations. They tailored a strategy that nurtured our community, resulting in increased brand loyalty and valuable user feedback. Their dedication and passion for engagement are unmatched. We highly recommend their services."},{"name":"Emily Chen","position":"Founder of Blockchain Solutions Ltd.","content":"HypeFarm\'s strategic campaigns and industry knowledge were instrumental in our successful ICO launch. Their support, community management, and branding guidance attracted the right investors and global attention. We couldn\'t have done it without them."},{"name":"Maria Rodriguez","position":"Marketing Manager at DeFi Innovations","content":"HypeFarm is an invaluable partner for our content marketing and SEO needs. Their insightful content and deep understanding of the blockchain space resonate with our audience. Their SEO strategies significantly improved our organic visibility and drove relevant traffic. We trust them to keep us at the forefront."},{"name":"David Thompson","position":"CEO of CryptoCommerce","content":"Choosing HypeFarm for web design and branding was a decision we\'ll never regret. They delivered a visually stunning and user-friendly website that perfectly represents our brand. Their expertise in Web3 technologies ensured seamless functionality. Their work speaks for itself, and we highly recommend them."}]');
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "react-use-draggable-scroll"
var external_react_use_draggable_scroll_ = __webpack_require__(72085);
;// CONCATENATED MODULE: ./src/pages/home/Testimonials.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Testimonials = ()=>{
    const ref2 = (0,external_react_.useRef)();
    const { events: events2  } = (0,external_react_use_draggable_scroll_.useDraggable)(ref2, {
        applyRubberBandEffect: true
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
        className: "bg-primary-1000 text-white py-12 px-7 mx:px-3",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("h1", {
                className: "text-5xl sm:text-3xl my-10 sm:my-7",
                children: "Feedback from Our Clients"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "flex sm:flex-wrap space-x-3 py-3 overflow-x-scroll sm:overflow-x-hidden scroll_box",
                ...events2,
                ref: ref2,
                children: testimonials_namespaceObject.map((e, i)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "reviews_item ",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                className: "text-base sm:text-sm text-left my-9",
                                children: e.content
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "text-primary-200 font-xl",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            children: e.name
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "text-primary-200",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            children: e.position
                                        })
                                    })
                                ]
                            })
                        ]
                    }, i))
            })
        ]
    });
};
/* harmony default export */ const home_Testimonials = (Testimonials);


/***/ })

};
;