exports.id = 826;
exports.ids = [826];
exports.modules = {

/***/ 27826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_CTA)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
// EXTERNAL MODULE: external "@material-tailwind/react"
var react_ = __webpack_require__(84715);
// EXTERNAL MODULE: ./src/components/button.css
var components_button = __webpack_require__(99087);
;// CONCATENATED MODULE: ./src/components/Button.jsx
/* __next_internal_client_entry_do_not_use__ ButtonOutlined,ButtonFilled,ButtonTransparent auto */ 


const ButtonFilled = ({ content  })=>{
    return /*#__PURE__*/ jsx_runtime.jsx("button", {
        className: "fill-btn text-base  bg-primary-500 hover:bg-primary-700 text-primary-1000 hover:text-primary-100 font-bold py-1 px-4 ",
        children: content
    });
};
const ButtonTransparent = ({ content  })=>{
    return /*#__PURE__*/ _jsx("div", {});
};
const ButtonOutlined = ({ content  })=>{
    return /*#__PURE__*/ _jsx(Button, {
        variant: "outlined",
        className: "border-primary-500 text-primary-500 hover:bg-primary-500 hover:text-white",
        children: content
    });
};


;// CONCATENATED MODULE: ./src/pages/home/CTA.jsx


const CTA = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
        className: "cta-section",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                className: "text-5xl text-center",
                children: "Partner With a Digital Marketing Agency That Delivers Growth"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "text-xl my-9 text-center",
                children: "We're a full-service digital marketing agency that helps brands that want to get noticed and dominate their industry. We love marketing. We eat, sleep and breathe it. But more importantly, we love seeing our clients grow their businesses with our help. There's nothing more satisfying than playing a pivotal role in the success of another business. Whether you're a fresh-faced startup or a seasoned enterprise, we want to be the one that helps you chart a course to explosive growth. If this sounds good to you, then let's talk."
            }),
            /*#__PURE__*/ jsx_runtime.jsx(ButtonFilled, {
                content: "Speak to our team"
            })
        ]
    });
};
/* harmony default export */ const home_CTA = (CTA);


/***/ }),

/***/ 99087:
/***/ (() => {



/***/ })

};
;