"use strict";
exports.id = 480;
exports.ids = [480];
exports.modules = {

/***/ 32480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_Services)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(85893);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(41664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(25675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/Card.jsx



const Card = ({ services  })=>{
    return services.map((e, i)=>/*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "max-w-sm bg-transparent hover:bg-gradient sm:bg-gradient rounded overflow-hidden rounded-tr-3xl rounded-bl-3xl m-4 pr-2",
            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                href: e.link,
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "px-6 py-4 hover:translate-x-1 ease-in duration-300 hover:ease-in hover:duration-300 ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex content-center ",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    alt: e.title,
                                    decoding: "async",
                                    "data-src": e.icon,
                                    className: " lazyloaded",
                                    src: e.icon,
                                    width: e.size.width,
                                    height: e.size.height
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("noscript", {
                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        width: e.size.width,
                                        height: e.size.height,
                                        src: e.icon,
                                        alt: e.title,
                                        decoding: "async"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "text-primary-900  text-xl ",
                                    children: e.title
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                            className: "text-gray-700 text-base my-3",
                            children: e.content
                        })
                    ]
                })
            })
        }, i));
};


;// CONCATENATED MODULE: ./public/services.json
const services_namespaceObject = JSON.parse('[{"title":"Community Management & Engagement","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-smm.svg","link":"https://ninjapromo.io/services/social-media","size":{"width":"37","height":"37"},"content":"Building and managing online communities for blockchain projects, including Twitter and discord platforms."},{"title":"Social Media Marketing","link":"https://ninjapromo.io/services/seo","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-seo.svg","size":{"width":"30","height":"30"},"content":"Developing and executing social media strategies tailored for the Web3 ecosystem, targeting platforms like Twitter, Telegram, Discord, and Reddit."},{"title":"Content Marketing","icon":"https://ninjapromo.io/wp-content/uploads/2022/12/ppc.svg","link":"https://ninjapromo.io/services/paid-media","size":{"width":"37","height":"37"},"content":"Developing content strategies and producing blog articles, whitepapers, case studies, and educational materials targeting specific blockchain audiences."},{"title":"Influencer Marketing","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-influencer.svg","link":"https://ninjapromo.io/services/influencer-marketing","size":{"width":"37","height":"37"},"content":" Identifying and collaborating with influential figures in the blockchain and crypto space to amplify brand reach and credibility."},{"title":"Marketing Strategy","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-pr.svg","link":"https://ninjapromo.io/services/public-relations","size":{"width":"35","height":"35"},"content":"Developing marketing strategies that are  custom made for ouR WEB 3 PARTNERS needs"},{"title":"Token Marketing & ICO/IDO Launchl","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-paid2.svg","link":"https://ninjapromo.io/services/paid-social","size":{"width":"37","height":"37"},"content":"Planning and executing marketing campaigns to raise awareness and promote Initial Coin Offerings (ICOs) or Initial DEX Offerings (IDOs)."}]');
;// CONCATENATED MODULE: ./src/pages/home/Services.jsx



const Services = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
        className: "services-section",
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "mb-20",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("h1", {
                        className: "services-title text-6xl sm:text-4xl font-medium mb-12 ",
                        children: [
                            "Our Digital ",
                            /*#__PURE__*/ jsx_runtime.jsx("br", {}),
                            " Marketing Services"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        className: "services-desc text-xl w-1/2 sm:w-full",
                        children: "We're experts in all things marketing. Business-to-business, cryptocurrency, NFT, and high-growth startup brands are our sweet spot. Discover how we can scale your business to new heights through our strategic services below:"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "services-items",
                children: /*#__PURE__*/ jsx_runtime.jsx(Card, {
                    services: services_namespaceObject
                })
            })
        ]
    });
};
/* harmony default export */ const home_Services = (Services);


/***/ })

};
;