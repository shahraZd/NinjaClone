(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 40252:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 97999:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/path-to-regexp");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 61090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 78652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 21668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 99399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppRouter: () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   LayoutRouter: () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   RenderFromTemplateContext: () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   StaticGenerationSearchParamsBailoutProvider: () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   __next_app_webpack_require__: () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   actionAsyncStorage: () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   createSearchParamsBailoutProxy: () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   decodeAction: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   decodeReply: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   preconnect: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   preloadFont: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   preloadStyle: () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   renderToReadableStream: () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   requestAsyncStorage: () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   serverHooks: () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   staticGenerationAsyncStorage: () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   staticGenerationBailout: () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(54592);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(76301);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57431);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30094);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(24437);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(46127);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45486);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(86404);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(95486);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(63332);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(27902);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(93099);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 710)), "C:\\Users\\shehe\\Desktop\\NinjaClone\\src\\app\\page.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38227)), "C:\\Users\\shehe\\Desktop\\NinjaClone\\src\\app\\layout.js"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 82819))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\shehe\\Desktop\\NinjaClone\\src\\app\\page.js"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/page"
  

/***/ }),

/***/ 45011:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 86249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 97844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 61522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 13100, 23))

/***/ }),

/***/ 16624:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27602));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 93365));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 28836))

/***/ }),

/***/ 11841:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31480))

/***/ }),

/***/ 31480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\app\\layout.js","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(85214);
var target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./src/app/globals.css
var globals = __webpack_require__(28360);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-icons/bi/index.esm.js
var index_esm = __webpack_require__(85228);
// EXTERNAL MODULE: ./node_modules/react-icons/ai/index.esm.js
var ai_index_esm = __webpack_require__(19722);
;// CONCATENATED MODULE: ./public/menu.json
const menu_namespaceObject = JSON.parse('[{"id":"0","title":"services","link":"/services"},{"id":"1","title":"Company","link":"/company"},{"id":"2","title":"Contact","link":"/contact"}]');
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/layout/navbar.css
var navbar = __webpack_require__(731);
// EXTERNAL MODULE: ./src/components/Button.jsx
var Button = __webpack_require__(27602);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
;// CONCATENATED MODULE: ./public/hypefarm-logo.svg
/* harmony default export */ const hypefarm_logo = ({"src":"/_next/static/media/hypefarm-logo.78c79ccc.svg","height":114,"width":956,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/layout/Nav.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









function Nav() {
    const [isHover, setIsHover] = (0,react_.useState)(false);
    const [menuOpen, setMenuOpen] = (0,react_.useState)(false);
    const [size, setSize] = (0,react_.useState)();
    const [scroll, setScroll] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        setSize(window.innerWidth);
        const storeScroll = ()=>{
            document.documentElement.dataset.scroll = window.scrollY;
            window.scrollY == 0 ? setScroll(false) : setScroll(true);
        };
        document.addEventListener("scroll", storeScroll, ()=>{});
        const handleResize = ()=>{
            setSize(window.innerWidth);
        };
        storeScroll();
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    }, []);
    (0,react_.useEffect)(()=>{
        if (size > 768 && menuOpen) {
            setMenuOpen(false);
        }
    }, [
        size,
        menuOpen
    ]);
    const menuToggleHandler = ()=>{
        setMenuOpen((prev)=>!prev);
    };
    console.log(size);
    return /*#__PURE__*/ jsx_runtime_.jsx("header", {
        className: `header ${isHover || scroll ? "header_bg_color" : "header_bg_trans"}`,
        onMouseOver: ()=>setIsHover(true),
        onMouseLeave: ()=>setIsHover(false),
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "header-content ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    className: "header__content__logo",
                    passHref: true
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                    className: ` ${size <= 768 ? menuOpen ? "nav isMenu" : "nav" : "menu"}`,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        children: [
                            menu_namespaceObject.map((e, i)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: e.link,
                                        children: e.title
                                    })
                                }, i)),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: `${size > 768 ? "hidden" : "block"}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/contact",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button.ButtonFilled, {
                                        content: "Book Intro Call"
                                    })
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `${size < 768 ? "hidden" : "block"}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/contact",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button.ButtonOutlined, {
                            content: "Book Intro Call"
                        })
                    })
                }),
                size <= 768 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "toggle",
                    children: !menuOpen ? /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* BiMenuAltRight */.fdF, {
                        onClick: menuToggleHandler
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(ai_index_esm/* AiOutlineClose */.oHP, {
                        onClick: menuToggleHandler
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const layout_Nav = (Nav);

;// CONCATENATED MODULE: ./src/layout/Footer.jsx

const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: " footer bg-primary-300 w-full ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "footer_container bg-black",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "footer_links",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "footer__subtitle",
                                children: "Subscribe to Our newsletter"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "footer__form",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "blog-hero__form",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "stc-subscribe-wrapper well"
                                    })
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "footer_copy",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: "\xa9 2017-2023 Ninjapromo.io"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            id: "menu-footer-copy-menu",
                            className: "",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    id: "menu-item-5266",
                                    className: "menu-item menu-item-type-post_type menu-item-object-page menu-item-5266",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://ninjapromo.io/privacy-policy",
                                        children: "Privacy Policy"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    id: "menu-item-5267",
                                    className: "menu-item menu-item-type-post_type menu-item-object-page menu-item-5267",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "https://ninjapromo.io/delivery-policy",
                                        children: "Terms & Conditions"
                                    })
                                })
                            ]
                        }),
                        " "
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layout_Footer = (Footer);

// EXTERNAL MODULE: ./node_modules/next/dist/client/components/noop-head.js
var noop_head = __webpack_require__(51824);
var noop_head_default = /*#__PURE__*/__webpack_require__.n(noop_head);
;// CONCATENATED MODULE: ./src/app/layout.js
/* __next_internal_client_entry_do_not_use__ metadata,default auto */ 





const metadata = {
    title: "HypeFarm",
    description: "A leading marketing agency specializing in community management and comprehensive marketing services."
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((noop_head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("link", {
                    rel: "icon",
                    href: "./favicon.ico",
                    sizes: "any"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
                className: (target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(layout_Nav, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("main", {
                        children: children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(layout_Footer, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 27602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ButtonFilled: () => (/* binding */ ButtonFilled),
/* harmony export */   ButtonOutlined: () => (/* binding */ ButtonOutlined),
/* harmony export */   ButtonTransparent: () => (/* binding */ ButtonTransparent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_tailwind_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18714);
/* harmony import */ var _material_tailwind_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _button_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12476);
/* harmony import */ var _button_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_button_css__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ ButtonOutlined,ButtonFilled,ButtonTransparent auto */ 


const ButtonFilled = ({ content  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "fill-btn text-base  bg-primary-500 hover:bg-primary-700 text-primary-1000 hover:text-primary-100 font-bold py-1 px-4 ",
        children: content
    });
};
const ButtonTransparent = ({ content  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {});
};
const ButtonOutlined = ({ content  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_tailwind_react__WEBPACK_IMPORTED_MODULE_1__.Button, {
        variant: "outlined",
        className: "border-primary-500 text-primary-500 hover:bg-primary-500 hover:text-white",
        children: content
    });
};



/***/ }),

/***/ 28836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_FAQ)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@material-tailwind/react/index.js
var react = __webpack_require__(18714);
;// CONCATENATED MODULE: ./src/components/Accordion.jsx



function Icon({ id , open  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: `${id === open ? "rotate-180" : ""} h-5 w-5 transition-transform`,
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        strokeWidth: 2,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            d: "M19 9l-7 7-7-7"
        })
    });
}
const MyAccordion = ({ item  })=>{
    const [open, setOpen] = (0,react_.useState)(0);
    const handleOpen = (value)=>{
        setOpen(open === value ? 0 : value);
    };
    //   useEffect(() => {
    //     setOpen(0);
    //   }, [open]);
    const customAnimation = {
        mount: {
            scale: 1
        },
        unmount: {
            scale: 0.9
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.Accordion, {
            open: open === item.order,
            icon: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                id: item.order,
                open: open
            }),
            animate: customAnimation,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(react.AccordionHeader, {
                    onClick: ()=>handleOpen(item.order),
                    className: ` hover:text-primary-200 ${open === item.order ? "text-primary-500" : "text-white"}`,
                    children: item.question
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(react.AccordionBody, {
                    className: "text-white text-base sm:text-sm",
                    children: item.answer
                })
            ]
        })
    });
};
/* harmony default export */ const Accordion = (MyAccordion);

;// CONCATENATED MODULE: ./public/faq.json
const faq_namespaceObject = JSON.parse('[{"order":1,"question":"How does your agency excel in community management?","answer":"Our expert community managers foster vibrant and engaged online communities within the Web3 ecosystem. They drive participation, cultivate brand advocates, and ensure a sense of belonging."},{"order":2,"question":"what is the client onboarding process like?","answer":"Our client onboarding process is streamlined and straightforward. We begin with an initial consultation, develop a tailored marketing strategy, provide a proposal, kick off the campaign, provide regular updates and reports, and maintain open communication throughout the engagement."},{"order":3,"question":"How can I get started with your agency?","answer":"Getting started is easy! Simply Book a call and meet with one of our experts to discuss your specific marketing needs and how we can help you achieve your goals in the Web3 ecosystem."}]');
;// CONCATENATED MODULE: ./src/pages/home/FAQ.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const FAQ = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "bg-primary-1000 text-white py-12 text-center flex flex-col justify-center align-center px-7",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                className: "text-2xl my-10 ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-5xl",
                        children: "FAQ. "
                    }),
                    "Popular Question From Our Clients"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mx-auto w-1/2 sm:w-full",
                children: faq_namespaceObject.map((e)=>/*#__PURE__*/ jsx_runtime_.jsx(Accordion, {
                        item: e
                    }, e.order))
            })
        ]
    });
};
/* harmony default export */ const home_FAQ = (FAQ);


/***/ }),

/***/ 93365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home_Testimonials)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
;// CONCATENATED MODULE: ./public/testimonials.json
const testimonials_namespaceObject = JSON.parse('[{"name":"Marc Dane","position":"CEO of CryptoTech Inc.","content":"HypeFarm\'s exceptional community management expertise exceeded our expectations. They tailored a strategy that nurtured our community, resulting in increased brand loyalty and valuable user feedback. Their dedication and passion for engagement are unmatched. We highly recommend their services."},{"name":"Emily Chen","position":"Founder of Blockchain Solutions Ltd.","content":"HypeFarm\'s strategic campaigns and industry knowledge were instrumental in our successful ICO launch. Their support, community management, and branding guidance attracted the right investors and global attention. We couldn\'t have done it without them."},{"name":"Maria Rodriguez","position":"Marketing Manager at DeFi Innovations","content":"HypeFarm is an invaluable partner for our content marketing and SEO needs. Their insightful content and deep understanding of the blockchain space resonate with our audience. Their SEO strategies significantly improved our organic visibility and drove relevant traffic. We trust them to keep us at the forefront."},{"name":"David Thompson","position":"CEO of CryptoCommerce","content":"Choosing HypeFarm for web design and branding was a decision we\'ll never regret. They delivered a visually stunning and user-friendly website that perfectly represents our brand. Their expertise in Web3 technologies ensured seamless functionality. Their work speaks for itself, and we highly recommend them."}]');
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-use-draggable-scroll/dist/index.js
var dist = __webpack_require__(60968);
;// CONCATENATED MODULE: ./src/pages/home/Testimonials.jsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Testimonials = ()=>{
    const ref2 = (0,react_.useRef)();
    const { events: events2  } = (0,dist.useDraggable)(ref2, {
        applyRubberBandEffect: true
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "bg-primary-1000 text-white py-12 px-7 mx:px-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-5xl sm:text-3xl my-10 sm:my-7",
                children: "Feedback from Our Clients"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex sm:flex-wrap space-x-3 py-3 overflow-x-scroll sm:overflow-x-hidden scroll_box",
                ...events2,
                ref: ref2,
                children: testimonials_namespaceObject.map((e, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "reviews_item ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-base sm:text-sm text-left my-9",
                                children: e.content
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-primary-200 font-xl",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: e.name
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-primary-200",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: e.position
                                        })
                                    })
                                ]
                            })
                        ]
                    }, i))
            })
        ]
    });
};
/* harmony default export */ const home_Testimonials = (Testimonials);


/***/ }),

/***/ 38227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   metadata: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\shehe\Desktop\NinjaClone\src\app\layout.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["metadata"];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 710:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
;// CONCATENATED MODULE: ./src/pages/home/Hero.jsx
// import BgHero from "../../../public/gradientHero/";

const Hero = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " text-center min-h-screen flex justify-center  ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                src: "https://hero.hypefarm.io/",
                width: "100%",
                frameborder: "0",
                height: "auto",
                className: "hero_section_bg "
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " hero_section_container   ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " mb-[4.25rem] sm:mb-[1.8rem] box-border  max-w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: " text-5xl sm:text-3xl ",
                                children: "Your Full Service Digital Marketing Company"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-5xl sm:text-3xl flex items-center justify-center ",
                                children: [
                                    "For",
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "hero-slider bg-primary-500 ml-8",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "hero-slider__words marquee",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Crypto"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Startups"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "B2B"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Software"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: "Fintech"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "hero-section_desc text-xl sm:text-base",
                        children: "A leading marketing agency specializing in community management and comprehensive marketing services. We aim to build thriving online communities, forge strong connections, and drive exceptional growth for businesses."
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const home_Hero = (Hero);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(34834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/Card.jsx



const Card = ({ services  })=>{
    return services.map((e, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "max-w-sm bg-transparent hover:bg-gradient sm:bg-gradient rounded overflow-hidden rounded-tr-3xl rounded-bl-3xl m-4 pr-2",
            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: e.link,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "px-6 py-4 hover:translate-x-1 ease-in duration-300 hover:ease-in hover:duration-300 ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex content-center ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    alt: e.title,
                                    decoding: "async",
                                    "data-src": e.icon,
                                    className: " lazyloaded",
                                    src: e.icon,
                                    width: e.size.width,
                                    height: e.size.height
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("noscript", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        width: e.size.width,
                                        height: e.size.height,
                                        src: e.icon,
                                        alt: e.title,
                                        decoding: "async"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-primary-900  text-xl ",
                                    children: e.title
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-gray-700 text-base my-3",
                            children: e.content
                        })
                    ]
                })
            })
        }, i));
};


;// CONCATENATED MODULE: ./public/services.json
const services_namespaceObject = JSON.parse('[{"title":"Community Management & Engagement","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-smm.svg","link":"https://ninjapromo.io/services/social-media","size":{"width":"37","height":"37"},"content":"Building and managing online communities for blockchain projects, including Twitter and discord platforms."},{"title":"Social Media Marketing","link":"https://ninjapromo.io/services/seo","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-seo.svg","size":{"width":"30","height":"30"},"content":"Developing and executing social media strategies tailored for the Web3 ecosystem, targeting platforms like Twitter, Telegram, Discord, and Reddit."},{"title":"Content Marketing","icon":"https://ninjapromo.io/wp-content/uploads/2022/12/ppc.svg","link":"https://ninjapromo.io/services/paid-media","size":{"width":"37","height":"37"},"content":"Developing content strategies and producing blog articles, whitepapers, case studies, and educational materials targeting specific blockchain audiences."},{"title":"Influencer Marketing","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-influencer.svg","link":"https://ninjapromo.io/services/influencer-marketing","size":{"width":"37","height":"37"},"content":" Identifying and collaborating with influential figures in the blockchain and crypto space to amplify brand reach and credibility."},{"title":"Marketing Strategy","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-pr.svg","link":"https://ninjapromo.io/services/public-relations","size":{"width":"35","height":"35"},"content":"Developing marketing strategies that are  custom made for ouR WEB 3 PARTNERS needs"},{"title":"Token Marketing & ICO/IDO Launchl","icon":"https://ninjapromo.io/wp-content/uploads/2023/02/services-paid2.svg","link":"https://ninjapromo.io/services/paid-social","size":{"width":"37","height":"37"},"content":"Planning and executing marketing campaigns to raise awareness and promote Initial Coin Offerings (ICOs) or Initial DEX Offerings (IDOs)."}]');
;// CONCATENATED MODULE: ./src/pages/home/Services.jsx



const Services = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "services-section",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mb-20",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        className: "services-title text-6xl sm:text-4xl font-medium mb-12 ",
                        children: [
                            "Our Digital ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            " Marketing Services"
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "services-desc text-xl w-1/2 sm:w-full",
                        children: "We're experts in all things marketing. Business-to-business, cryptocurrency, NFT, and high-growth startup brands are our sweet spot. Discover how we can scale your business to new heights through our strategic services below:"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "services-items",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Card, {
                    services: services_namespaceObject
                })
            })
        ]
    });
};
/* harmony default export */ const home_Services = (Services);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./src/components/Button.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\shehe\Desktop\NinjaClone\src\components\Button.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["ButtonOutlined"];

const e1 = proxy["ButtonFilled"];

const e2 = proxy["ButtonTransparent"];

;// CONCATENATED MODULE: ./src/pages/home/CTA.jsx


const CTA = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "cta-section",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-5xl text-center",
                children: "Partner With a Digital Marketing Agency That Delivers Growth"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-xl my-9 text-center",
                children: "We're a full-service digital marketing agency that helps brands that want to get noticed and dominate their industry. We love marketing. We eat, sleep and breathe it. But more importantly, we love seeing our clients grow their businesses with our help. There's nothing more satisfying than playing a pivotal role in the success of another business. Whether you're a fresh-faced startup or a seasoned enterprise, we want to be the one that helps you chart a course to explosive growth. If this sounds good to you, then let's talk."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(e1, {
                content: "Speak to our team"
            })
        ]
    });
};
/* harmony default export */ const home_CTA = (CTA);

;// CONCATENATED MODULE: ./src/pages/home/Contact.jsx

const Contact = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "Contact"
    });
};
/* harmony default export */ const home_Contact = (Contact);

;// CONCATENATED MODULE: ./src/pages/home/Testimonials.jsx

const Testimonials_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\shehe\Desktop\NinjaClone\src\pages\home\Testimonials.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Testimonials_esModule, $$typeof: Testimonials_$$typeof } = Testimonials_proxy;
const Testimonials_default_ = Testimonials_proxy.default;


/* harmony default export */ const Testimonials = (Testimonials_default_);
;// CONCATENATED MODULE: ./src/pages/home/Blog.jsx

const Blog = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: "Blog"
    });
};
/* harmony default export */ const home_Blog = (Blog);

;// CONCATENATED MODULE: ./src/pages/home/FAQ.jsx

const FAQ_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\shehe\Desktop\NinjaClone\src\pages\home\FAQ.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: FAQ_esModule, $$typeof: FAQ_$$typeof } = FAQ_proxy;
const FAQ_default_ = FAQ_proxy.default;


/* harmony default export */ const FAQ = (FAQ_default_);
// EXTERNAL MODULE: ./src/pages/home/home.css
var home = __webpack_require__(8950);
;// CONCATENATED MODULE: ./src/pages/home/index.jsx









const Home = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(home_Hero, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(home_Services, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(home_CTA, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Testimonials, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(FAQ, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(home_Blog, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(home_Contact, {})
        ]
    });
};
/* harmony default export */ const pages_home = (Home);

;// CONCATENATED MODULE: ./src/app/page.js
// import Body from "../layout/Body";


const App = ()=>/*#__PURE__*/ jsx_runtime_.jsx(pages_home, {});
/* harmony default export */ const page = (App);


/***/ }),

/***/ 82819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 28360:
/***/ (() => {



/***/ }),

/***/ 12476:
/***/ (() => {



/***/ }),

/***/ 731:
/***/ (() => {



/***/ }),

/***/ 8950:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [405,925], () => (__webpack_exec__(99399)));
module.exports = __webpack_exports__;

})();