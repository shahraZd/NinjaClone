"use strict";
(() => {
var exports = {};
exports.id = 155;
exports.ids = [155];
exports.modules = {

/***/ 97783:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 28530:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@opentelemetry/api");

/***/ }),

/***/ 54426:
/***/ ((module) => {

module.exports = require("next/dist/compiled/chalk");

/***/ }),

/***/ 40252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 32196:
/***/ ((module) => {

module.exports = require("next/dist/compiled/ua-parser-js");

/***/ }),

/***/ 14021:
/***/ ((module) => {

module.exports = import("next/dist/compiled/@vercel/og/index.node.js");;

/***/ }),

/***/ 20926:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./node_modules/next/dist/build/webpack/loaders/next-metadata-route-loader.js?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__
var favicon_next_metadata_namespaceObject = {};
__webpack_require__.r(favicon_next_metadata_namespaceObject);
__webpack_require__.d(favicon_next_metadata_namespaceObject, {
  GET: () => (GET),
  dynamic: () => (dynamic)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(35387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(29267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./node_modules/next/server.js
var server = __webpack_require__(14664);
;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-metadata-route-loader.js?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!./src/app/favicon.ico?__next_metadata__


const contentType = "image/x-icon"
const buffer = Buffer.from("AAABAAEAICAAAAEAIACoEAAAFgAAACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAACMuAAAjLgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvOwrBb3tLxK+7TMTv+44E8DuPBTA7z4MAAAAAAAAAAAAAAAAAAAAAMHyUAzB8lQUwfNXFMHzWRTA9FsUv/RXBwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC97Sw7vu0wyr/uNtHA7jvRwe9A1MHvQ4zB8UcCAAAAAAAAAAAAAAAAwvJWgMPzW9bD9F7TwvRh08L1ZNLB9WJIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL3tLWG+7TH/v+42/8DuO//B70H/we9Et8DwQgYAAAAAAAAAAL7wOwLD81ipw/Nd/8P0YP/D9WT/wvVn/8H1ZHYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC36BUBve0sm77tMf+/7jb/wO47/8HvQf/B70TLwO9CEQAAAAAAAAAAwPFKCcPzWbzD813/w/Rg/8P1ZP/C9Wf/wfZmsL3zUwYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALzsJy+97Cvjvu0x/7/uNv/A7jv/we9A/8HvROTB8EQlAAAAAAAAAADC8VEbw/NZ2sPzXf/D9GD/w/Vk/8L1Z//B9mjuwPVjPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC66yAPvOwmqr3sK/++7TH/v+42/8DuO//B70D/we9F+cHwRVEAAAAAAAAAAMLyU0LD81n0w/Nd/8P0YP/D9WT/wvVn/8L2af/A9mm7v/VgFwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuesbGLrrIJq77CX9vewr/77tMf+/7jb/wO47/8HvQP/B8EX/wvBHkwAAAAAAAAAAwvJUg8PzWf/D813/w/Rg/8P1ZP/C9Wf/wvZp/8H3bP/A92qqvvZkIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALHoAAGz6QYHtekNG7fqE1m46xrEuusf/7vsJf+97Cv/vu0x/7/uNv/A7jv/we9A/8HwRf/C8EjYwfBGHcLxThPD8lXMw/NZ/8PzXf/D9GD/w/Vk/8L1Z//C9mn/wfds/8D3bv+/927OvfdrZbv3ZSK59l4JuPZZAQAAAAAAAAAAsegBQrPpBbe16QzYtuoT+bjqGf+66x//u+wl/73sK/++7TH/v+42/8DuO//B70D/wfBF/8LwSf7C8EpswvJQXcPyVvrD81n/w/Nd/8P0YP/D9WT/wvVn/8L2af/B92z/wPdu/7/4cP+++HH8vPlx37v5cr+5+W1bAAAAAAAAAACx6AFls+kF/7XpDP+26hP/uOoZ/7rrH/+77CX/vewr/77tMOy/7jbKwO47/8HvQP/B8EX/wvBJ/8LxTdzD8VHWw/JW/8PzWf/D813/w/Rg/8L0Yc3C9WbmwvZp/8H3bP/A927/v/hw/775cv+9+XT/u/p1/7r5b4gAAAAAAAAAALHoAWOz6QX/tekM/7bqE/+46hn/uusf/7vsJf+97Cveve0uVr/uNjfA7jvowe9A/8HwRf/C8En/wvFO/8PxUv/D8lb/w/NZ/8PzXf/D9F/wwvNbQsH1YU3B9mjZwfds/8D3bv+/+HD/vvly/735dP+7+nX/uvlvhgAAAAAAAAAAsegBY7PpBf+16Qz/tuoT/7jqGf+66x/xu+wkpbzsKTEAAAAAvO0qAsDuO5TB70D/wfBF/8LwSf/C8U7/w/FS/8PyVv/D81n/w/Nd/8L0XaLA8lEGAAAAAMD1YSzA9migwPdt77/4cP+++XL/vfl0/7v6df+6+W+GAAAAAAAAAACx6AFfs+kF8rXpDOe26hLJuOoZjrnrHkC66yEHAAAAAAAAAAAAAAAAwO47KcHvQNnB8EX/wvBJ/8LxTv/D8VL/w/JW/8PzWv/D81ziwvNYMwAAAAAAAAAAAAAAAL3zVAW/9mY9vvdsjr34b8q8+XLou/lz+Lr5boIAAAAAAAAAALHoARqz6QU6tOkMJ7bqERAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwe9Ah8HwRf/C8En/wvFO/8PxUv/D8lb/w/NZ/8LzWZmf3AABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvPZgEbz4aim6+GhBufdjJgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAv+4zB8DuO2HB70DgwfBF/8LwSf/C8U7/w/FS/8PyVv/D81n/w/Nc5sL0W2vA8lIKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAue0cAb7tMTC/7jagwO479sHvQP/B8EX/wvBJ/8LxTv/D8VL/w/JW/8PzWf/D813/w/Rg+cL0YKjB9F42ue8xAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuusfDrvsJT297CuRvu0x5L/uNv/A7jv/we9A/8HwRf/C8En/wvFO/8PxUv/D8lb/w/NZ/8PzXf/D9GD/w/Vj/8L1ZejB9WWYwPVkQb71XRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsegBErPpBTC16Qw/t+oTXbjrGYu66x/Du+wl8L3sK/++7TH/v+42/8DuO//B70D/wfBF/8LwSf/C8Uy1w/FRssPyVv7D81n/w/Nd/8P0YP/D9WT/wvVn/8L2af/B9mvywPdrx773bJG992tjvPdoR7v5cjK6+WwWAAAAAAAAAACx6AFcs+kF7rXpDPS26hP9uOoZ/7rrH/+77CX/vewr/77tMf+/7jb/wO47/8HvQP/B70XzwvBHjMHwRxLB8UwRwvJUh8PzWfHD813/w/Rg/8P1ZP/C9Wf/wvZp/8H3bP/A927/v/hw/774cv+9+XL3u/p08br5bHMAAAAAAAAAALHoAWSz6QX/tekM/7bqE/+46hn/uusf/7vsJf+97Cv/vu0x/7/uNv/A7jv+we8/x8HvQlG/7zwEAAAAAAAAAAC+8EIDwvJWTsPzXMbD9GD+w/Vk/8L1Z//C9mn/wfds/8D3bv+/+HD/vvly/735dP+7+nT/uvlsfAAAAAAAAAAAsegBY7PpBf+16Qz/tuoT/7jqGf+66x//u+wl/73sK/++7TH7v+41z8DuOXDA7jwXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwvJVFsLzXXHC9GLPwvVm+8L2af/B92z/wPdu/7/4cP+++XL/vfl0/7v6dP+6+Wx7AAAAAAAAAACx6AFls+kF/7XpDP+26hP/uOoZ/7rrH/i77CXfvOwqqb7tL1y+7TMYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMH0WxfB9WJcwfZmqcH2at/A9235v/hw/775cv+9+XT/u/p1/7r5bH0AAAAAAAAAALHoAUyz6QW7tekMsLbqEpq46hl3uusfTLvsJCG77CUFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC981AFv/ViIr/2Z06+92t6vfhtnrz5crO7+XDDufhoYQAAAAAAAAAAsegBBbPpBQm06QsEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuvVaBbj1VQy49VUHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//////////////////////8DwP//AcD//wGA//4BgH/+AYB//AGAP/gBgB+AAAABgAAAAYAAAAGAAAABgEACAYDgBwGH8Afh/8AD//8AAP/8AAA/gAAAAYAAAAGAAYABgAfgAYAf+AGAf/4Bj///8f////////////////////8=", 'base64'
  )

function GET() {
  return new server.NextResponse(buffer, {
    headers: {
      'Content-Type': contentType,
      'Cache-Control': "public, max-age=0, must-revalidate",
    },
  })
}

const dynamic = 'force-static'

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Ffavicon.ico%2Froute&name=app%2Ffavicon.ico%2Froute&pagePath=private-next-app-dir%2Ffavicon.ico&appDir=C%3A%5CUsers%5Cshehe%5CDesktop%5CNinjaClone%5Csrc%5Capp&appPaths=%2Ffavicon.ico&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=!

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/favicon.ico/route","pathname":"/favicon.ico","filename":"favicon","bundlePath":"app/favicon.ico/route"},"resolvedPagePath":"next-metadata-route-loader?page=%2Ffavicon.ico%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js!C:\\Users\\shehe\\Desktop\\NinjaClone\\src\\app\\favicon.ico?__next_metadata__","nextConfigOutput":""}
    const routeModule = new (module_default())({
      ...options,
      userland: favicon_next_metadata_namespaceObject,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/favicon.ico/route"

    

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [405,572], () => (__webpack_exec__(20926)));
module.exports = __webpack_exports__;

})();