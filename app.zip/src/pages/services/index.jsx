"use client";
import React, { useEffect, useState } from "react";
// import { BiMenuAltRight } from "react-icons/bi";
// import { AiOutlineClose } from "react-icons/ai";
import Link from "next/link";

const Services = () => {
  return (
    <section className="bg-primary-1000 text-white min-h-full">
      Services
    </section>
  );
};

export default Services;
