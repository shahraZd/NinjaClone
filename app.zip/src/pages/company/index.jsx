import Link from "next/link"
const About = () => {
    return (
      <ul>
        <li>
          <Link href="/">Home</Link>
        </li>
        <li>
         
        </li>
        <li>
          <Link href="/blog/hello-world">Blog Post</Link>
        </li>
      </ul>
    )
  }

  export default About