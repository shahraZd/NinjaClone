// import Body from "../layout/Body";
import Home from "@/pages/home";

const App = () => <Home />;

export default App;
