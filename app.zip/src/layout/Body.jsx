// import Home from "../pages/home";

// export default function () {
//     return (
//        <div>
//          <Home/>

//        </div>
//      )
//   }
